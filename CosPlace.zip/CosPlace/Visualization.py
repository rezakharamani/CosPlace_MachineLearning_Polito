#! C:\CosPlace-main\MyP\Scripts\python.exe



# imported necessary libraries to show labels on a diagram and show some images with plot or PIL
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import matplotlib.image as mpimge
from PIL import Image
import os 



#
# some information about the code and dataset 
# 1- the dataset SF_XS is composed of three folders ---> training folder - evaluation folder with queries - test folder with queries
# 2-#




# step 1 -----> checking the dataset SF_XS that how dense they are 

path_training_folder = r"E:\\DataSet\\sf_xs\\train"
train_path = os.listdir(path_training_folder)

path_eval_folder = r"E:\\DataSet\\sf_xs\\val\\database"
path_eval_query_folder = r"E:\\DataSet\\sf_xs\\val\\queries"

path_test_folder = r"E:\\DataSet\\sf_xs\\test\\database"
path_test_query_folder = r"E:\\DataSet\\sf_xs\\test\\queries"

def Check_density(path1 , path2):
    counter = []
    if os.path.basename(path1) == "train":
        for i , dirname in enumerate(path2[:10]):
            for j in os.listdir(path1 + "\\"+str(dirname)):
                counter.append(j.split("@"))
    else: 
        for k in  os.listdir(path1):
            counter.append(k.split("@"))

    return len(counter)


print("\n\n\n\n")
Number_trains = Check_density(path_training_folder,train_path)
print(f"The Number of images in train folder are : {Number_trains}" )

Number_eval = Check_density(path_eval_folder , "Null")
print(f"The Number of images in evaluation dataset folder are : {Number_eval}")

Number_query_eval  = Check_density(path_eval_query_folder, "Null")
print(f"The Number of images in evaluation query folder : {Number_query_eval}")

Number_test  = Check_density(path_test_folder, "Null")
print(f"The Number of images in test dataset folder are : {Number_test}")

Number_query_test = Check_density(path_test_query_folder, "Null")
print(f"The Number of images in test query are : {Number_query_test}")

print("\n\n\n\n")




## step 2 ----> plotting and presentation of the density or distribution of the images in a pie chart 

fig, ax = plt.subplots(figsize=(7, 5), subplot_kw=dict(aspect="equal"))
recipe = [Number_trains , Number_eval , Number_query_eval , Number_test , Number_query_test]

data = [x for x in recipe]
ingredients = [x for x in recipe] 

def func(pct, allvals):
    absolute = int(np.round(pct/100.*np.sum(allvals)))
    return f"{pct:.1f}%\n({absolute:d} Numbers)"

wedges, texts, autotexts = ax.pie(data, autopct=lambda pct: func(pct, data),
                                  textprops=dict(color="w"))
ax.legend(wedges, ["Train Folder" , "Evalution Folder" , "Evaluation query Folder" , "Test Folder" , "Test query Folder"],
          title="Number of images per Folder",
          loc="center left",
          bbox_to_anchor=(.81,0,0.2,0.2))

plt.setp(autotexts, size=8, weight="bold")
ax.set_title("Prsentation of image distribution in a pie chart")
plt.show()


#------------------------------



fig, ax = plt.subplots(figsize = (10,6))
data = ['Train Folder', 'Evaluation Folder', 'Evaluation Query Folder', 'Test Folder' , 'Test Query Folder']
counts = [Number_trains, Number_eval, Number_query_eval, Number_test, Number_query_test]
bar_labels = ['Train Folder', 'Evaluation Folder', 'Evaluation Query Folder', 'Test Folder' , 'Evaluation Query Folder']
bar_colors = ['tab:red', 'tab:blue', 'tab:cyan', 'tab:orange' , 'tab:green']

ax.bar(data, counts, label=bar_labels, color=bar_colors)

for i, v in enumerate(counts):
    ax.text(i, v + 1, str(v), ha='center', fontsize=10)


ax.set_ylabel('distribution of images')
ax.set_title('Image Distribution')
ax.legend(title='Distribution Color')

plt.show()


# step  -----> this section is for showin with section has label or not
#               accoriding to the data review, all of the sections have labels except the query folder of test dataset 
#               so here we showed data labels for some images of train folder - test folder and test query folder in the DataFrame
# 


trainFolder  = path_training_folder+"\\"+"37.70"
testFolder = path_test_folder
testqueryFolder = path_test_query_folder

def getlabel(path):
    counter = 0
    limit = 5

    DataLabel = []
    for i in os.listdir(path):
        if counter  <= limit:
            DataLabel.append(i.split("@"))
            counter+=1
        else:
            break
    return DataLabel

print("-------------------------------------------------------------------")

# below is the print of some image labels in the train folder
print("image labels for train Folder are as follows:")
X = getlabel(trainFolder)
for i in range(len(X)):
    print(X[i][7])
# print one Sample of train 
print(f"\n{X[1]}\n")

# below is the print of some image labels in the test dataset folder
print("image labels for test dataset folder are as follows:")
Y = getlabel(testFolder)
for i in range(len(Y)):
    print(X[i][7])
# print one Sample test
print(f"\n{Y[1]}\n")

# below is the print of some image labels in the test query folder 
print("image labels for test queru folder are as follows:")
Z = getlabel(testqueryFolder)
for i in range(len(Z)):
    print(Z[i][7])
# print one sample of test query
print("According to the print data in the command prompt we have noticed that there is no label for the test query and they are Null")
print(f"\n{Z[1]}\n")

print("-------------------------------------------------------------------")












# step 3  -----> getting the information from geotagged of images in one of the train folders Number 37.70 and save in an array

# getting the direction of one folder from train dataset of 'SF_XS' and receive information tagged below each image as a useful info
# like latitude, longitude, depth level of sea , Direction like south,west,north,east and so on ... (the green command below describes all of the beneficial data)
impage_path = r"E:\\eBooks on Pdf Expert\\Data Science Polito\\Second Semester\\Machine and Deep Learning\\Machine Learning Polito\\DataSet\\sf_xs\\train\\37.70"
imageName = []

for i in os.listdir(impage_path):
    imageName.append(i.split("@"))

# Step 2 -----> getting the path of some images to show by matplotlib 

# getting the direction of one folder from train dataset of 'SF_XS' and show some images on the plot 
path2 = "E:/eBooks on Pdf Expert/Data Science Polito/Second Semester/Machine and Deep Learning/Machine Learning Polito/DataSet/sf_xs/train/37.70/"
MyImage = []
for i in os.listdir(path2):
    MyImage.append(i)

fig ,ax = plt.subplots(2 , 3 , figsize = (5,5))
for i in range(6):
    t =Image.open(path2+MyImage[i])
    ax[i//3 , i%3].imshow(t) ## here is for showing six images 3*3
    ax[i//3 , i%3].axis('off')
plt.show()



# step 4 -----> described inforramtion about name of images which are important
# --> all the images except query images in test section has name/unique identifier 

## below is the beneficial information about one name tagged below an image in the directory
# [[[[[[@ 0544204.32 @ 4173406.33 @ 10 @ S @ 037.70683 @ -122.49851 @ TYcjxIohRl--XFaR4OgdxA @@ 0 @@@@ 201910 @@ .jpg]]]]]]

# 0544204.32: This appears to be a latitude coordinate, possibly in decimal degrees format.
# 4173406.33: This appears to be a longitude coordinate, possibly in decimal degrees format.
# 10: This could be an altitude value, measured in meters above sea level.
# S: This could be a letter code indicating the direction of the altitude value (e.g. "N" for north or "S" for south).
# 037.70683: This appears to be a latitude coordinate in degrees, minutes, and seconds format.
# -122.49851: This appears to be a longitude coordinate in degrees, minutes, and seconds format.
# TYcjxIohRl--XFaR4OgdxA: This could be a unique identifier for the image file.
# 0: This could be a value indicating the orientation of the image (e.g. "0" for normal orientation or "1" for 90 degrees clockwise).
# 201910: This could be a date value, possibly indicating when the image was taken (in this case, October 2019).
# .jpg: This is the file extension for the image file.


# setp 5 -----> converting the input data to a DataFrame and getting thier location to show in the plot 
  
# here we have separated all the useful information to save and show in a DataFrame called df
df = pd.DataFrame(imageName , columns = ["A", "latitude_imagelocation" , "longitude_imagelocation" , "depth_above_sea" , "direction" , "latitude_degrees", "longitude_degrees" , "identifier" ,"B", "value","C","D","E","date [year/month]","F","G"])
df = df.iloc[:,[1,2,3,4,5,6,7,9,13]]
print(df)


# setp 6 -----> plot a part of train data labed to visit thier distribution 
#  notice  : the distribution of the most of the data are the same and some of them are more  

# here is a function defined in order to plot some labels and show thier distribution by thier counts(thier Numbers)

plot1 = df.iloc[2000:2150,6]

def plotting_datalabel(dataframe):
    label_counts = np.unique(dataframe, return_counts=True)
    labels = label_counts[0]
    counts = label_counts[1]

    plt.bar(labels, counts)
    plt.title('Label distribution')
    plt.xlabel('Label')
    plt.ylabel('Count')
    plt.xticks(rotation = 90)
    plt.show()

plotting_datalabel(plot1)



