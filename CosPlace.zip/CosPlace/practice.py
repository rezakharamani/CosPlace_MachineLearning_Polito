import numpy as np
import padnas as pd 
import matplotlib.pyplot as plt 


pathfile = r""

data = pd.read_csv(pathfile)


from sklearn.model_selection import train_test_split
x_train , x_test , y_train  , y_test = train_test_split(x,y , test_size = 0.25 , stratify=y , random_state = 42)

from sklearn.preprocessing import StandardScaler
Scaler = StandardScaler()
x_train  = Scaler.fir_transorm(x_train)
x_test = Scaler.transform(x_test)

from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier(n_neighbors=7)
model.fit(x_train,y_train)

y_pred = model.predict(x_test)

from sklearn.metrics  import accuracy_score
acc = accuracy_score(y-test, y_pred)
print(acc)


## if there is a huge minority and majority between data 
# accuracy_score is not a good criteria to evaluate the accuracy 
# 
# so we have to use confusion matrix for get accuracy recall and so on 
 

from sklearn.metrics import confusion_matrix
matrix = confusion_matrix(y_test, y_pred)
dataframe  = pd.DataFrame(matrix , index = [0,1] , columns = [0,1])
print(matrix)

__________________________________________________________________

import torch 
from torch import nn

data = pd.read_csv(pathfile)

# using manual train test split 

train_split_size  = int(0.8 * len(x))

x_train , y_train = [:train_split_size] , [:train_split_size]
x_test , y_test = [train_split_size:] , [train_split_size:]

def plottingdata(train_data = x_train, train_labels = y_train , test_data = x_test, test_labels = y_test , predictions = None):

    plt.fugure(figsize=(4,6))

    plt.scatter (x,y,c='b' , s= 4)
    plt.scatter(test_data , test_labels , c = 'r')

    if predictions is not None:
        plt.scatter(test_data , predictions , c = "g" , s = 3)

    plt.legend(labels = ["Train" , "Test"])
    plt.show()



class LinearRegression(torch.nn):

    self.weights = nn.parameter(torch.randn(1,requires_grad = True , dtype = torch.float))

    sel.bias = nn.parameter(torch.randn(1,requires_grad = True, dtype = torch.float))


    def forward(self , x :torch.tensor) -> torch.tensor:
        return self.weights * x + self.bias



## at running time 

torch.manual_seed(40)
model = LinearRegression()
list(model.parameter())

y_pred = model.predict(x_test)
y_pred


with torch.inference_mode():
    y_pred = model.predict(x_test)

y_pred

plottingdata(predictions=y_pred)  

model.state_dict()


# to evaluate the ccuracy of the data we have to use loss function



## loss is for know our project is correct or not 
# it is an creteria for evaluation the correctness of the model
# 
# loss Function or cost Function 
# Optimization 
#   



